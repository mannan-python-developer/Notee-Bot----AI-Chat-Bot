import torch
import os
import glob
from transformers import GPT2LMHeadModel, GPT2Tokenizer
import pandas as pd
import gradio as gr

def read_all_text_files_into_dataframe(directory_path, file_extension='txt'):
    files = glob.glob(os.path.join(directory_path, f'*.{file_extension}'))

    data_frames = []
    for file_path in files:
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                content = file.read()
            df = pd.DataFrame(data={'Filename': [file_path], 'Content': [content]})
            data_frames.append(df)
        except Exception as e:
            print(f"Error reading file at {file_path}: {e}")

    if data_frames:
        return pd.concat(data_frames, ignore_index=True)
    else:
        return None

notes_df = read_all_text_files_into_dataframe(r'G:\Machine Learning\Datasets\New folder\Notes')

def search_in_notes(query, notes_df):
    for note in notes_df['Content']:
        if query.lower() in note.lower():
            return True
    return False

def get_data_from_notes(query, notes_df):
    relevant_data = []
    for i, note in enumerate(notes_df['Content']):
        if query.lower() in note.lower():
            relevant_data.append(notes_df['Content'][i])
    return relevant_data

# Load GPT-2 model and tokenizer
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = GPT2LMHeadModel.from_pretrained("gpt2")
model.to(device)
model.eval()
tokenizer = GPT2Tokenizer.from_pretrained("gpt2")



def chat_with_bot(user_query, notes_df):
    # Check if the query is present in the notes
    if search_in_notes(user_query, notes_df):
        # Fetch relevant data from the notes
        relevant_data = get_data_from_notes(user_query, notes_df)
        return f"Found in notes :)\n{' '.join(relevant_data)}"
    else: 
        # If not found in notes, use the GPT-2 model
        input_ids = tokenizer.encode(user_query, return_tensors="pt").to(device)
        with torch.no_grad():
            output = model.generate(input_ids, max_length=200, num_beams=5, no_repeat_ngram_size=2, top_k=50, top_p=0.95)
        response = tokenizer.decode(output[0], skip_special_tokens=True)
        return f"Genreted by GPT-2:\n{response}"


iface = gr.Interface(
    fn=lambda Search: chat_with_bot(Search, notes_df),
    inputs=gr.Textbox(),
    outputs="text",
    theme="gr",
    title="Notee Bot"
)

iface.launch()
